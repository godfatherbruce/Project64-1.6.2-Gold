sources of midis :

http://en.midimelody.ru/
http://www.mirsoft.info/
https://www.vgmusic.com/
http://www.angelfire.com/sd/par/midi.html
https://www.midiworld.com/
https://www.youtube.com/watch?v=Z9SG8C6h2Yo
http://www.chaumetsoftware.com/canta/display.php?path=/BrassensGeorges

other interesting midi sites:

https://bitmidi.com/
https://ifdo.ca/~seymour/midipage/
http://aimamidi.tripod.com/m/index.htm


The sequences name are like this :

03_brassenshecatombe_29

Instrument set used _ Name of the song _ Sequence number where the song is injected in Master of Time 

All ported by doncamilo